import React, { useState } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  flexRender,
} from '@tanstack/react-table';
import './StudentTable.css';

const LoadingSkeleton = () => (
  <div className="skeleton-wrapper">
    <div className="skeleton-header"></div>
    <div className="skeleton-table">
      <div className="skeleton-row">
        <div className="skeleton-cell skeleton-cell-15"></div>
        <div className="skeleton-cell skeleton-cell-15"></div>
        <div className="skeleton-cell skeleton-cell-20"></div>
        <div className="skeleton-cell skeleton-cell-25"></div>
        <div className="skeleton-cell skeleton-cell-25"></div>
      </div>
      <div className="skeleton-row">
        <div className="skeleton-cell skeleton-cell-15"></div>
        <div className="skeleton-cell skeleton-cell-15"></div>
        <div className="skeleton-cell skeleton-cell-20"></div>
        <div className="skeleton-cell skeleton-cell-25"></div>
        <div className="skeleton-cell skeleton-cell-25"></div>
      </div>
    </div>
  </div>
);

const StudentTable = ({ data }) => {
  const [expandedRow, setExpandedRow] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleExpand = (rowId) => {
    if (isAnimating) return;
    
    if (expandedRow === rowId) {
      setIsAnimating(true);
      const element = document.querySelector('.parent-details');
      if (element) {
        element.classList.add('collapse');
        setTimeout(() => {
          setExpandedRow(null);
          setIsAnimating(false);
          setIsLoading(false);
        }, 300);
      }
    } else {
      setExpandedRow(rowId);
      setIsAnimating(true);
      setIsLoading(true);
      
      // Simulate loading delay
      setTimeout(() => {
        setIsLoading(false);
        setIsAnimating(false);
      }, 3000); // 3 seconds delay
    }
  };

  const columns = [
    {
      header: '',
      id: 'expander',
      cell: ({ row }) => (
        <button
          className="expand-button"
          onClick={() => handleExpand(row.id)}
          disabled={isAnimating}
        >
          <span className={`arrow ${expandedRow === row.id ? 'expanded' : ''}`}>
            {expandedRow === row.id ? '▼' : '▶'}
          </span>
        </button>
      ),
    },
    {
      header: 'Name',
      accessorKey: 'name',
    },
    {
      header: 'Age',
      accessorKey: 'age',
    },
    {
      header: 'Blood Group',
      accessorKey: 'bloodGroup',
    },
  ];

  const renderParentDetails = (row) => {
    const parentDetails = row.original.parentDetails;
    
    if (isLoading) {
      return (
        <div className="parent-details">
          <h4>Parent Details</h4>
          <div className="parent-details-container">
            <LoadingSkeleton />
          </div>
        </div>
      );
    }

    return (
      <div className="parent-details">
        <h4>Parent Details</h4>
        <div className="parent-details-container">
          <table className="inner-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Primary Address</th>
                <th>Secondary Address</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{parentDetails.name}</td>
                <td>{parentDetails.phone}</td>
                <td>{parentDetails.email}</td>
                <td>{parentDetails.primaryAddress}</td>
                <td>{parentDetails.secondaryAddress}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div className="table-container">
      <div className="table-wrapper">
        <table>
          <thead>
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th key={header.id}>
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map(row => (
              <React.Fragment key={row.id}>
                <tr>
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
                {expandedRow === row.id && (
                  <tr className="detail-row">
                    <td colSpan={columns.length}>
                      {renderParentDetails(row)}
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StudentTable;