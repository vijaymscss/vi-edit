import React, { useState } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  getExpandedRowModel,
  getPaginationRowModel,
  flexRender,
} from '@tanstack/react-table';
import './StudentTable.css';

const StudentTable = ({ data }) => {
  const [sorting, setSorting] = useState([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [columnFilters, setColumnFilters] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [bloodGroupFilter, setBloodGroupFilter] = useState('');
  const [showColumnFilters, setShowColumnFilters] = useState(false);

  const uniqueBloodGroups = [...new Set(data.map(student => student.bloodGroup))].sort();

  const handleEdit = (student) => {
    // Add your edit logic here
    console.log('Edit student:', student);
  };

  const handleDelete = (student) => {
    // Add your delete logic here
    console.log('Delete student:', student);
  };

  const handleBloodGroupFilter = (bloodGroup) => {
    setExpanded({});
    if (bloodGroup === bloodGroupFilter) {
      setBloodGroupFilter(''); // Clear filter if same button is clicked
    } else {
      setBloodGroupFilter(bloodGroup);
    }
  };

  const filteredData = React.useMemo(() => {
    if (!bloodGroupFilter) return data;
    return data.filter(student => student.bloodGroup === bloodGroupFilter);
  }, [data, bloodGroupFilter]);

  const columns = [
    {
      accessorKey: 'name',
      header: 'Name',
    },
    {
      accessorKey: 'age',
      header: 'Age',
    },
    {
      accessorKey: 'bloodGroup',
      header: 'Blood Group',
    },
    {
      id: 'actions',
      header: 'Actions',
      cell: ({ row }) => (
        <div className="action-buttons">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(row.original);
            }}
            className="action-btn edit"
          >
            Edit
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.original);
            }}
            className="action-btn delete"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  const table = useReactTable({
    data: filteredData,
    columns,
    state: {
      sorting,
      globalFilter,
      columnFilters,
      expanded,
    },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnFiltersChange: setColumnFilters,
    onExpandedChange: setExpanded,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getRowCanExpand: () => true,
    initialState: {
      pagination: {
        pageSize: 3,
      },
    },
  });

  const renderDetailPanel = (row) => {
    const student = row.original;
    return (
      <div className="detail-panel">
        <h3>Student Details</h3>
        <div className="detail-grid">
          <div className="detail-item">
            <span className="label">Email:</span>
            <span>{student.email}</span>
          </div>
          <div className="detail-item">
            <span className="label">Phone:</span>
            <span>{student.phone}</span>
          </div>
          <div className="detail-item">
            <span className="label">Address:</span>
            <span>{student.address}</span>
          </div>
          <div className="detail-item">
            <span className="label">Grade:</span>
            <span>{student.grade}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="table-container">
      <div className="table-controls">
        <div className="search-controls">
          <input
            type="text"
            value={globalFilter}
            onChange={(e) => setGlobalFilter(e.target.value)}
            placeholder="Search all columns..."
            className="global-search"
          />
          <button 
            onClick={() => setShowColumnFilters(!showColumnFilters)}
            className={`toggle-filters-btn ${showColumnFilters ? 'active' : ''}`}
          >
            {showColumnFilters ? 'Hide Filters' : 'Show Filters'}
          </button>
        </div>
        <div className="blood-group-filters">
          {uniqueBloodGroups.map((bloodGroup) => (
            <button
              key={bloodGroup}
              onClick={() => handleBloodGroupFilter(bloodGroup)}
              className={`blood-group-btn ${bloodGroupFilter === bloodGroup ? 'active' : ''}`}
            >
              {bloodGroup}
            </button>
          ))}
          {bloodGroupFilter && (
            <button
              onClick={() => setBloodGroupFilter('')}
              className="blood-group-btn clear"
            >
              Clear Filter
            </button>
          )}
        </div>
      </div>
      <table>
        <thead>
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              <th></th> {/* Expansion column */}
              {headerGroup.headers.map((header) => (
                <th key={header.id}>
                  <div
                    className={`th-content ${
                      header.column.getCanSort() ? 'sortable' : ''
                    }`}
                    onClick={header.column.getToggleSortingHandler()}
                  >
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                    {header.column.getIsSorted() && (
                      <span>
                        {header.column.getIsSorted() === 'asc' ? ' ↑' : ' ↓'}
                      </span>
                    )}
                  </div>
                  {header.column.getCanFilter() && showColumnFilters && (
                    <input
                      type="text"
                      value={header.column.getFilterValue() ?? ''}
                      onChange={(e) =>
                        header.column.setFilterValue(e.target.value)
                      }
                      placeholder={`Search ${header.column.columnDef.header}...`}
                      className="column-search"
                    />
                  )}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <React.Fragment key={row.id}>
              <tr>
                <td>
                  <button
                    onClick={() => row.toggleExpanded()}
                    className="expand-button"
                  >
                    {row.getIsExpanded() ? '▼' : '▶'}
                  </button>
                </td>
                {row.getVisibleCells().map((cell) => (
                  <td key={cell.id}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
              {row.getIsExpanded() && (
                <tr className="detail-row">
                  <td colSpan={row.getVisibleCells().length + 1}>
                    {renderDetailPanel(row)}
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
      <div className="pagination">
        <button
          onClick={() => table.setPageIndex(0)}
          disabled={!table.getCanPreviousPage()}
          className="pagination-btn"
        >
          {'<<'}
        </button>
        <button
          onClick={() => table.previousPage()}
          disabled={!table.getCanPreviousPage()}
          className="pagination-btn"
        >
          {'<'}
        </button>
        <span className="pagination-info">
          Page {table.getState().pagination.pageIndex + 1} of{' '}
          {table.getPageCount()}
        </span>
        <button
          onClick={() => table.nextPage()}
          disabled={!table.getCanNextPage()}
          className="pagination-btn"
        >
          {'>'}
        </button>
        <button
          onClick={() => table.setPageIndex(table.getPageCount() - 1)}
          disabled={!table.getCanNextPage()}
          className="pagination-btn"
        >
          {'>>'}
        </button>
      </div>
    </div>
  );
};

export default StudentTable;