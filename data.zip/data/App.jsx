import React from 'react';
import StudentTable from './StudentTable';
import './App.css';

function App() {
  const studentData = [
    { id: 1, name: 'John Doe', age: 20, bloodGroup: 'A+', address: '123 Main St', phone: '555-0101', email: 'john@example.com', grade: 'A' },
    { id: 2, name: 'Jane Smith', age: 21, bloodGroup: 'B-', address: '456 Oak Ave', phone: '555-0102', email: 'jane@example.com', grade: 'B+' },
    { id: 3, name: 'Mike Johnson', age: 19, bloodGroup: 'O+', address: '789 Pine Rd', phone: '555-0103', email: 'mike@example.com', grade: 'A-' },
    { id: 4, name: 'Sarah Wilson', age: 22, bloodGroup: 'AB+', address: '321 Elm St', phone: '555-0104', email: 'sarah@example.com', grade: 'B' },
    { id: 5, name: 'Tom Brown', age: 20, bloodGroup: 'A-', address: '654 Maple Dr', phone: '555-0105', email: 'tom@example.com', grade: 'A+' },
    { id: 6, name: 'Emily Davis', age: 21, bloodGroup: 'O-', address: '987 Cedar Ln', phone: '555-0106', email: 'emily@example.com', grade: 'B-' },
    { id: 7, name: 'David Lee', age: 19, bloodGroup: 'B+', address: '147 Birch Rd', phone: '555-0107', email: 'david@example.com', grade: 'A' },
    { id: 8, name: 'Lisa Anderson', age: 22, bloodGroup: 'AB-', address: '258 Walnut Ave', phone: '555-0108', email: 'lisa@example.com', grade: 'B+' },
    { id: 9, name: 'James Taylor', age: 20, bloodGroup: 'A+', address: '369 Pine St', phone: '555-0109', email: 'james@example.com', grade: 'A-' },
    { id: 10, name: 'Amy Martin', age: 21, bloodGroup: 'O+', address: '741 Oak Rd', phone: '555-0110', email: 'amy@example.com', grade: 'B' }
  ];

  return (
    <div className="app">
      <h1>Student Records</h1>
      <StudentTable data={studentData} />
    </div>
  );
}

export default App;