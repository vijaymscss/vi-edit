import React, { useState, useMemo, useEffect, lazy, Suspense } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getExpandedRowModel,
  getSortedRowModel,
  flexRender,
} from '@tanstack/react-table';
import './App.css';
import { generateData, generateSubTableData } from './data';

// Skeleton Loader Component
const SkeletonLoader = () => {
  return (
    <tr className="skeleton-loader">
      <td colSpan={10}>
        <table className="sub-table-skeleton">
          <tbody>
            {[1, 2, 3].map((_, index) => (
              <tr key={index} className="skeleton-row">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((cell) => (
                  <td key={cell} className="skeleton-cell"></td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </td>
    </tr>
  );
};

// Delayed Sub Table Component
const DelayedSubTable = () => {
  const [tableData, setTableData] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setTableData(generateSubTableData());
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (!tableData) {
    return <SkeletonLoader />;
  }

  return (
    <div className="sub-table-container">
      <table className="sub-table">
        <thead>
          <tr>
            <th>Hierarchy</th>
            <th>Action</th>
            <th>App Name</th>
            <th>Branch</th>
            <th>Build No</th>
            <th>Suite Name</th>
            <th>Started Time</th>
            <th>End Time</th>
            <th>Expected Time</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((item, index) => (
            <tr key={index}>
              <td>{item.hierarchy}</td>
              <td>{item.action}</td>
              <td>{item.appName}</td>
              <td>{item.branch}</td>
              <td>{item.buildNo}</td>
              <td>{item.suiteName}</td>
              <td>{item.startedTime}</td>
              <td>{item.endTime}</td>
              <td>{item.expectedTime}</td>
              <td className={`status-${item.status.toLowerCase()}`}>
                {item.status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const App = () => {
  const [data, setData] = useState(() => generateData(10));
  const [expanded, setExpanded] = useState({});
  const [globalFilter, setGlobalFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [envFilter, setEnvFilter] = useState('all');
  const [sorting, setSorting] = useState([]);

  // Handle single row expansion
  const handleExpand = (rowId) => {
    setExpanded(prev => {
      // If clicking the same row, collapse it
      if (prev[rowId]) {
        return {};
      }
      // If clicking a different row, expand only that row
      return { [rowId]: true };
    });
  };

  // Collapse expanded rows when any filter changes
  useEffect(() => {
    setExpanded({});
  }, [globalFilter, envFilter, sorting, showFilters]);

  const columns = useMemo(
    () => [
      {
        header: '',
        id: 'expander',
        cell: ({ row }) => (
          <button 
            className="expand-button"
            onClick={(e) => {
              e.stopPropagation();
              handleExpand(row.id);
            }}
          >
            {row.getIsExpanded() ? '▼' : '▶'}
          </button>
        ),
      },
      {
        header: 'Environment',
        accessorKey: 'environment',
        cell: info => info.getValue(),
      },
      {
        header: 'Workflow Name',
        accessorKey: 'workflowName',
        cell: info => info.getValue(),
      },
      {
        header: 'Trigger Schedule',
        accessorKey: 'triggerSchedule',
        cell: info => info.getValue(),
      },
      {
        header: 'Status',
        accessorKey: 'status',
        cell: info => (
          <span className={`status-${info.getValue().toLowerCase()}`}>
            {info.getValue()}
          </span>
        ),
      },
    ],
    []
  );

  const filteredData = useMemo(() => {
    let filtered = [...data];
    if (envFilter !== 'all') {
      filtered = filtered.filter(item => item.environment === envFilter);
    }
    return filtered;
  }, [data, envFilter]);

  const table = useReactTable({
    data: filteredData,
    columns,
    state: {
      expanded,
      globalFilter,
      sorting,
    },
    onSortingChange: setSorting,
    onExpandedChange: setExpanded,
    getSubRows: row => row.subRows,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getExpandedRowModel: getExpandedRowModel(),
    getSortedRowModel: getSortedRowModel(),
    enableSorting: true,
  });

  return (
    <div className="container">
      <h1>Workflow Table</h1>
      
      <div className="controls">
        <input
          type="text"
          value={globalFilter}
          onChange={e => setGlobalFilter(e.target.value)}
          placeholder="Global Search..."
          className="search-input"
        />
        
        <div className="env-filters">
          <button
            className={envFilter === 'all' ? 'active' : ''}
            onClick={() => setEnvFilter('all')}
          >
            All
          </button>
          {['env1', 'env2', 'env3'].map(env => (
            <button
              key={env}
              className={envFilter === env ? 'active' : ''}
              onClick={() => setEnvFilter(env)}
            >
              {env}
            </button>
          ))}
        </div>
        
        <button
          className="toggle-filters"
          onClick={() => setShowFilters(!showFilters)}
        >
          {showFilters ? 'Hide Filters' : 'Show Filters'}
        </button>
      </div>

      <div className="table-wrapper">
        <div className="table-container">
          <table>
            <thead>
              {table.getHeaderGroups().map(headerGroup => (
                <tr key={headerGroup.id}>
                  {headerGroup.headers.map(header => (
                    <th 
                      key={header.id}
                      onClick={header.column.getToggleSortingHandler()}
                      className={header.column.getCanSort() ? 'sortable' : ''}
                    >
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                      {header.column.getCanSort() && (
                        <span className="sort-indicator">
                          {header.column.getIsSorted() === 'asc' ? ' ▲' : 
                           header.column.getIsSorted() === 'desc' ? ' ▼' : ' ↕'}
                        </span>
                      )}
                      {showFilters && header.column.getCanFilter() && (
                        <div className="column-filter">
                          <input
                            type="text"
                            onChange={e =>
                              header.column.setFilterValue(e.target.value)
                            }
                            placeholder={`Filter ${header.column.columnDef.header}`}
                          />
                        </div>
                      )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map(row => (
                <React.Fragment key={row.id}>
                  <tr
                    className={row.getIsExpanded() ? 'expanded' : ''}
                  >
                    {row.getVisibleCells().map(cell => (
                      <td key={cell.id}>
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </td>
                    ))}
                  </tr>
                  {row.getIsExpanded() && (
                    <tr className="sub-table-row">
                      <td colSpan={columns.length}>
                        <DelayedSubTable />
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="pagination">
        <button
          onClick={() => table.setPageIndex(0)}
          disabled={!table.getCanPreviousPage()}
        >
          {'<<'}
        </button>
        <button
          onClick={() => table.previousPage()}
          disabled={!table.getCanPreviousPage()}
        >
          {'<'}
        </button>
        <span>
          Page{' '}
          <strong>
            {table.getState().pagination.pageIndex + 1} of{' '}
            {table.getPageCount()}
          </strong>
        </span>
        <button
          onClick={() => table.nextPage()}
          disabled={!table.getCanNextPage()}
        >
          {'>'}
        </button>
        <button
          onClick={() => table.setPageIndex(table.getPageCount() - 1)}
          disabled={!table.getCanNextPage()}
        >
          {'>>'}
        </button>
      </div>
    </div>
  );
};

export default App;